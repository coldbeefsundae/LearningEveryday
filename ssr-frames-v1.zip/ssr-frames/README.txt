StarQuest SSR regional frames v1 (11 regions)
CN China, JP Japan, KR Korea, CA Canada, EU Europe, AM North America,
SA South America, AF Africa, AU Australia & Oceania, AS Asia & Mideast, GL Global

originals-on-black/  generated artwork, 1024x1536 (2:3), decoration on pure black
transparent-webp/    overlays used by the demo, 720x1008 (5:7 card size), transparent
transparent-png/     same overlays as PNG (lossless), for editing
